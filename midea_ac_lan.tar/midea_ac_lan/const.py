DOMAIN = "midea_ac_lan"
COMPONENT = "component"
DEVICES = "devices"
CONF_KEY = "key"
CONF_MODEL = "model"
MIDEA_DEFAULT_ACCOUNT = 'b99226f1659e9308@hotmail.com'
MIDEA_DEFAULT_PASSWORD = '_d0e4e9546a738d_'
MIDEA_DEFAULT_SERVER = "not_cn"
